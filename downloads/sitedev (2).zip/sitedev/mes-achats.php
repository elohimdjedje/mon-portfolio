<?php
$title = "Mes Achats - Ma Bibliothèque";
include 'header.php';
include 'db.php';

if (!isset($_SESSION['utilisateur_id'])) {
    header("Location: connexion.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT l.titre, p.date_ajout 
    FROM panier p 
    JOIN livres l ON p.livre_id = l.id 
    WHERE p.utilisateur_id = ?");
$stmt->bind_param("i", $_SESSION['utilisateur_id']);
$stmt->execute();
$result = $stmt->get_result();
?>

<main class="container py-5">
    <h2 class="fw-bold text-center">Livres achetés</h2>
    <?php if ($result->num_rows > 0): ?>
        <ul class="list-group">
            <?php while ($row = $result->fetch_assoc()): ?>
                <li class="list-group-item">
                    <strong><?php echo htmlspecialchars($row['titre']); ?></strong>
                    <br>
                    Date d'achat : <?php echo htmlspecialchars($row['date_ajout']); ?>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p class="text-center text-muted">Aucun livre acheté pour le moment.</p>
    <?php endif; ?>
</main>

<?php include 'footer.php'; ?>
