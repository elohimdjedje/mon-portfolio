<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Utilisateurs - Ma Bibliothèque";
include 'admin_header.php'; // Header spécifique à l'administration
include 'db.php'; // Connexion à la base de données
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Gestion des Utilisateurs</h1>

    <div class="table-responsive">
        <table class="table table-hover table-bordered align-middle">
            <thead class="table-primary text-center">
                <tr>
                    <th>#</th>
                    <th>Prénom</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Rôle</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Récupérer les utilisateurs
                $sql = "SELECT * FROM utilisateurs";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $statusBadge = $row['statut'] === 'Actif'
                            ? "<span class='badge bg-success'>Actif</span>"
                            : "<span class='badge bg-danger'>Bloqué</span>";
                        ?>
                        <tr>
                            <td class="text-center"><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['prenom']); ?></td>
                            <td><?php echo htmlspecialchars($row['nom']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td class="text-center"><?php echo htmlspecialchars($row['role']); ?></td>
                            <td class="text-center"><?php echo $statusBadge; ?></td>
                            <td class="text-center">
                                <!-- Voir Détails -->
    <a href="user_details.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">
        Détails
    </a>

                                <!-- Bloquer/Débloquer -->
                                <?php if ($row['statut'] === 'Actif'): ?>
                                    <form action="block_user.php" method="POST" class="d-inline">
                                        <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="btn btn-warning btn-sm">Bloquer</button>
                                    </form>
                                <?php else: ?>
                                    <form action="unblock_user.php" method="POST" class="d-inline">
                                        <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="btn btn-success btn-sm">Débloquer</button>
                                    </form>
                                <?php endif; ?>
                                <!-- Supprimer -->
                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $row['id']; ?>">
                                    Supprimer
                                </button>
                            </td>
                        </tr>

                        <!-- Modal Détails -->
                        <div class="modal fade" id="detailsModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-primary" id="detailsModalLabel">Détails de l'utilisateur</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>ID :</strong> <?php echo htmlspecialchars($row['id']); ?></p>
                                        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($row['prenom']); ?></p>
                                        <p><strong>Nom :</strong> <?php echo htmlspecialchars($row['nom']); ?></p>
                                        <p><strong>Email :</strong> <?php echo htmlspecialchars($row['email']); ?></p>
                                        <p><strong>Rôle :</strong> <?php echo htmlspecialchars($row['role']); ?></p>
                                        <p><strong>Statut :</strong> <?php echo htmlspecialchars($row['statut']); ?></p>
                                        <p><strong>Date d'inscription :</strong> <?php echo htmlspecialchars($row['date_inscription']); ?></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal Suppression -->
                        <div class="modal fade" id="deleteModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-danger" id="deleteModalLabel">Confirmer la suppression</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Êtes-vous sûr de vouloir supprimer l'utilisateur <strong><?php echo htmlspecialchars($row['prenom'] . ' ' . $row['nom']); ?></strong> ?
                                    </div>
                                    <div class="modal-footer">
                                        <form action="delete_user.php" method="POST">
                                            <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                            <button type="submit" class="btn btn-danger">Supprimer</button>
                                        </form>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center text-muted'>Aucun utilisateur trouvé.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
