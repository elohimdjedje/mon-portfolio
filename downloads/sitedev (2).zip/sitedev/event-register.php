<?php
session_start(); // Démarrer la session

// Inclure le fichier de connexion à la base de données
include 'db.php'; 

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['utilisateur_id'])) {
    echo "Veuillez vous connecter pour vous inscrire à un événement.";
    exit;
}

// Vérifier si un ID d'événement est fourni
if (!isset($_GET['event_id'])) {
    echo "Aucun événement spécifié.";
    exit;
}

$event_id = intval($_GET['event_id']); // ID de l'événement
$utilisateur_id = $_SESSION['utilisateur_id']; // ID de l'utilisateur connecté

// Enregistrer l'inscription dans la base de données
$sql = "INSERT INTO inscriptions (utilisateur_id, event_id, date_inscription) VALUES ($utilisateur_id, $event_id, NOW())";

if ($conn->query($sql) === TRUE) {
    echo "Inscription réussie à l'événement !";
} else {
    echo "Erreur : " . $conn->error;
}

$conn->close();
?>
