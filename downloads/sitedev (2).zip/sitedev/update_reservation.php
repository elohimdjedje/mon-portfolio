<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reservation_id = $_POST['reservation_id'];

    if (isset($_POST['confirm'])) {
        $stmt = $conn->prepare("UPDATE reservations SET statut = 'Confirmée' WHERE id = ?");
        $stmt->bind_param("i", $reservation_id);
        $stmt->execute();
        $_SESSION['success_message'] = "Réservation confirmée avec succès.";
    }

    if (isset($_POST['cancel'])) {
        $stmt = $conn->prepare("UPDATE reservations SET statut = 'Annulée' WHERE id = ?");
        $stmt->bind_param("i", $reservation_id);
        $stmt->execute();
        $_SESSION['success_message'] = "Réservation annulée avec succès.";
    }

    header("Location: manage_reservations.php");
    exit;
}
?>
