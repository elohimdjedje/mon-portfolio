<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include 'db.php'; // Connexion à la base de données
$title = "Détails de l'utilisateur - Ma Bibliothèque";
include 'admin_header.php';

// Vérifier si l'ID est passé en paramètre
if (!isset($_GET['id'])) {
    echo "<div class='alert alert-danger text-center'>ID utilisateur manquant.</div>";
    include 'admin_footer.php';
    exit;
}

$user_id = intval($_GET['id']);

// Récupérer les détails de l'utilisateur
$stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<div class='alert alert-danger text-center'>Utilisateur introuvable.</div>";
    include 'admin_footer.php';
    exit;
}

$user = $result->fetch_assoc();
?>

<main class="container py-5">
    <h1 class="text-center text-primary">Détails de l'utilisateur</h1>
    <div class="row justify-content-center mt-4">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Informations personnelles</h5>
                    <p><strong>Prénom : </strong><?php echo htmlspecialchars($user['prenom']); ?></p>
                    <p><strong>Nom : </strong><?php echo htmlspecialchars($user['nom']); ?></p>
                    <p><strong>Email : </strong><?php echo htmlspecialchars($user['email']); ?></p>
                    <p><strong>Date d'inscription : </strong><?php echo htmlspecialchars($user['date_inscription']); ?></p>
                    <p><strong>Statut : </strong>
                        <span class="badge <?php echo $user['statut'] === 'Actif' ? 'bg-success' : 'bg-danger'; ?>">
                            <?php echo htmlspecialchars($user['statut']); ?>
                        </span>
                    </p>
                    <a href="manage_users.php" class="btn btn-secondary mt-3">Retour</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
