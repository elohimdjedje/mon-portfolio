<?php
$title = "Romance - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<main class="py-5">
    <div class="container">
        <h2 class="fw-bold mb-4 text-center text-primary">Livres de Romance</h2>
        <div class="row g-4">
            <?php
            // Inclure la connexion à la base de données
            include 'db.php';

            // Préparer et exécuter la requête pour récupérer les livres de la catégorie "Romance"
            $stmt = $conn->prepare("SELECT * FROM livres WHERE categorie = ? AND statut = ?");
            $categorie = "Romance";
            $statut = "Disponible";
            $stmt->bind_param("ss", $categorie, $statut);
            $stmt->execute();
            $result = $stmt->get_result();

            // Vérifier s'il y a des livres dans la catégorie
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-4">
                        <div class="book-card p-3 shadow-sm h-100">
                            <a href="book-details.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="text-decoration-none text-dark">
                                <div class="d-flex">
                                    <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['titre']); ?>" class="book-img me-3" style="width: 80px; height: 120px; object-fit: cover;">
                                    <div>
                                        <h5 class="fw-bold"><?php echo htmlspecialchars($row['titre']); ?></h5>
                                        <p class="text-muted mb-1">par <span class="fw-bold"><?php echo htmlspecialchars($row['auteur']); ?></span></p>
                                        <p class="text-muted small"><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<div class='col-12'><p class='text-center text-muted'>Aucun livre disponible dans cette catégorie pour le moment.</p></div>";
            }

            // Fermer la requête et la connexion
            $stmt->close();
            $conn->close();
            ?>
        </div>
    </div>
</main>

<?php include 'footer.php'; // Inclusion du footer ?>
