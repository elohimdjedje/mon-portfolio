<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>
    <!-- Contenu de la page -->
    <main>
        <section class="py-5">
            <div class="container">
                <h2 class="fw-bold text-center mb-4">Nos Services</h2>
                <div class="row g-4">
                    <!-- Service 1 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-book-open fa-3x text-primary mb-3"></i>
                                <h5 class="card-title fw-bold">Prêt de Livres</h5>
                                <p class="card-text">Empruntez vos livres préférés gratuitement avec votre carte de bibliothèque.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Service 2 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-laptop fa-3x text-primary mb-3"></i>
                                <h5 class="card-title fw-bold">Accès Internet</h5>
                                <p class="card-text">Utilisez nos ordinateurs ou Wi-Fi pour vos recherches et vos projets personnels.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Service 3 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-chalkboard-teacher fa-3x text-primary mb-3"></i>
                                <h5 class="card-title fw-bold">Ateliers & Conférences</h5>
                                <p class="card-text">Participez à des ateliers d'écriture, conférences, et autres événements éducatifs.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-4 mt-4">
                    <!-- Service 4 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-child fa-3x text-primary mb-3"></i>
                                <h5 class="card-title fw-bold">Activités Jeunesse</h5>
                                <p class="card-text">Des activités créatives et ludiques pour les enfants de tous âges.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Service 5 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-headphones fa-3x text-primary mb-3"></i>
                                <h5 class="card-title fw-bold">Livres Audio</h5>
                                <p class="card-text">Découvrez notre collection de livres audio pour profiter d'une lecture autrement.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Service 6 -->
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-map-marker-alt fa-3x text-primary mb-3"></i>
                                <h5 class="card-title fw-bold">Espace de Lecture</h5>
                                <p class="card-text">Un espace calme et confortable pour lire, étudier, ou simplement se détendre.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; // Inclusion du footer ?>
    
</body>
</html>
