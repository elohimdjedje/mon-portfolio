<?php
$title = "Mes Emprunts - Ma Bibliothèque";
include 'header.php';
include 'db.php';

if (!isset($_SESSION['utilisateur_id'])) {
    header("Location: connexion.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT l.titre, e.date_emprunt, e.date_retour 
    FROM emprunts e 
    JOIN livres l ON e.livre_id = l.id 
    WHERE e.utilisateur_id = ? AND e.statut = 'En cours'");
$stmt->bind_param("i", $_SESSION['utilisateur_id']);
$stmt->execute();
$result = $stmt->get_result();
?>

<main class="container py-5">
    <h2 class="fw-bold text-center">Mes Emprunts</h2>
    <?php if ($result->num_rows > 0): ?>
        <ul class="list-group">
            <?php while ($row = $result->fetch_assoc()): ?>
                <li class="list-group-item">
                    <strong><?php echo htmlspecialchars($row['titre']); ?></strong>
                    <br>
                    Emprunté le : <?php echo htmlspecialchars($row['date_emprunt']); ?>
                    <br>
                    Date de retour : <?php echo htmlspecialchars($row['date_retour'] ?: 'Non défini'); ?>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p class="text-center text-muted">Aucun emprunt en cours.</p>
    <?php endif; ?>
</main>

<?php include 'footer.php'; ?>
