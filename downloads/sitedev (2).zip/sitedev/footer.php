<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row">
            <!-- Section À propos -->
            <div class="col-md-4">
                <h5 class="fw-bold">À propos de nous</h5>
                <p class="text-muted">
                    📚 Ma Bibliothèque est votre espace pour explorer, lire, et emprunter vos livres préférés. Nous nous engageons à rendre la lecture accessible à tous.
                </p>
            </div>

            <!-- Section Liens utiles -->
            <div class="col-md-4">
                <h5 class="fw-bold">Liens utiles</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white text-decoration-none">Accueil</a></li>
                    <li><a href="romance.php" class="text-white text-decoration-none">Romance</a></li>
                    <li><a href="humour.php" class="text-white text-decoration-none">Humour</a></li>
                    <li><a href="services.php" class="text-white text-decoration-none">Services</a></li>
                    <li><a href="contact.php" class="text-white text-decoration-none">Contact</a></li>
                    <li><a href="cart.php" class="text-white text-decoration-none">Mon panier</a></li>
                </ul>
            </div>

            <!-- Section Contact -->
            <div class="col-md-4">
                <h5 class="fw-bold">Contactez-nous</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt me-2"></i> 123 Rue de la Lecture, Paris</li>
                    <li><i class="fas fa-phone-alt me-2"></i> +33 1 23 45 67 89</li>
                    <li><i class="fas fa-envelope me-2"></i> contact@mabibliotheque.fr</li>
                </ul>

                <!-- Réseaux sociaux -->
                <div class="mt-3">
                    <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                    <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                    <a href="#" class="text-white"><i class="fab fa-linkedin fa-lg"></i></a>
                </div>
            </div>
        </div>

        <hr class="my-4 text-muted">

        <!-- Section Copyright -->
        <div class="text-center">
            <p class="mb-0">&copy; 2024 Ma Bibliothèque. Tous droits réservés. | <a href="#" class="text-white text-decoration-none">Mentions légales</a></p>
        </div>
    </div>
</footer>
</body>
</html>
