
<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Le Clown Perdu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container py-5">
        <div class="row">
            <!-- Image du livre -->
            <div class="col-md-4">
                <img src="https://via.placeholder.com/200x300" alt="Le Clown Perdu" class="img-fluid shadow">
            </div>
            <!-- Détails du livre -->
            <div class="col-md-8">
                <h1>Le Clown Perdu</h1>
                <p class="text-muted">par <span class="fw-bold">Jean Rire</span></p>
                <h5 class="mt-4">Résumé</h5>
                <p>
                    Une aventure hilarante où un clown se retrouve embarqué dans des situations imprévues et hilarantes qui vous feront éclater de rire à chaque page.
                </p>
                <h5>À propos de ce livre</h5>
                <ul>
                    <li>250 pages</li>
                    <li>5-6 heures de lecture</li>
                    <li>Humour captivant et unique</li>
                </ul>
                <h5 class="mt-4">Prix</h5>
                <p><span class="fw-bold text-danger">12,99 €</span></p>
                <a href="#" class="btn btn-danger">Ajouter au panier</a>
                <a href="#" class="btn btn-outline-secondary">Ajouter à ma liste d'envies</a>

                <h5 class="mt-4">État</h5>
                <p>
                    <span class="badge bg-danger">Indisponible</span>
                </p>
                <!-- Bouton Réserver -->
                <a href="mes-reservations.html" class="btn btn-primary rounded-pill">Réserver ce livre</a>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; // Inclusion du footer ?>
</body>
</html>
