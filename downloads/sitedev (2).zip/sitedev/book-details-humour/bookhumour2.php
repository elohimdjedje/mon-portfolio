
<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blagues à part</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container py-5">
    <div class="row">
        <div class="col-md-4">
            <img src="https://via.placeholder.com/200x300" alt="Blagues à part" class="img-fluid shadow">
        </div>
        <div class="col-md-8">
            <h1>Blagues à part</h1>
            <p class="text-muted">par <span class="fw-bold">Sarah Fun</span></p>
            <h5 class="mt-4">Résumé</h5>
            <p>Un recueil des blagues les plus drôles et des anecdotes inoubliables...</p>
            <h5>À propos de ce livre</h5>
            <ul>
                <li>150 pages</li>
                <li>2-3 heures de lecture</li>
                <li>45k mots</li>
            </ul>
            <h5 class="mt-4">Prix</h5>
            <p><span class="fw-bold text-danger">7,99 €</span></p>
            <a href="#" class="btn btn-danger">Ajouter au panier</a>
            <a href="#" class="btn btn-outline-secondary">Ajouter à ma liste d'envies</a>
        </div>
    </div>
</div>
<?php include 'footer.php'; // Inclusion du footer ?>
</body>
</html>
