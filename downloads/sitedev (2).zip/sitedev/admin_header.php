<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'db.php'; // Connexion à la base de données
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Admin - Ma Bibliothèque'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style_admin.css">
</head>
<body>
    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <div class="container-fluid">
            <a class="navbar-brand" href="admin_dashboard.php">📚 Admin - Ma Bibliothèque</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="manage_books.php">📚 Livres</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">👥 Utilisateurs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_reservations.php">📑 Réservations</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_emprunts.php">📦 Emprunts</a>
                    </li>
                    <!-- Onglet Notifications -->
                    <li class="nav-item">
                        <a class="nav-link" href="manage_notifications.php">
                            🔔 Notifications
                            <?php
                            // Compteur des notifications non lues
                            $result = $conn->query("SELECT COUNT(*) AS total FROM notifications WHERE statut = 'Non lu'");
                            $count = $result->fetch_assoc()['total'];
                            if ($count > 0) {
                                echo "<span class='badge bg-danger ms-1'>$count</span>";
                            }
                            ?>
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="deconnexion.php">🔓 Déconnexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
