<?php
session_start();
include 'db.php'; // Connexion à la base de données

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Préparation de la requête
    $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE email = ? AND role = 'Admin'");
    if (!$stmt) {
        die("Erreur dans la requête SQL : " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();

        // Vérification du mot de passe
        if (password_verify($password, $admin['password'])) {
            // Connexion réussie
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_email'] = $admin['email'];
            header("Location: admin_dashboard.php"); // Redirige vers le tableau de bord
            exit;
        } else {
            $_SESSION['admin_error'] = "Mot de passe incorrect.";
        }
    } else {
        $_SESSION['admin_error'] = "Aucun compte administrateur trouvé.";
    }

    $stmt->close();
}

header("Location: admin_login.php"); // Redirige vers la page de connexion
exit;
?>
