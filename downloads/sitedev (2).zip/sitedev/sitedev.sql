-- Créer la base de données
CREATE DATABASE IF NOT EXISTS sitedev;
USE sitedev;

-- Table utilisateurs
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prenom VARCHAR(100) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Utilisateur', 'Admin') DEFAULT 'Utilisateur',
    date_inscription TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table catégories
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
);

-- Table livres
CREATE TABLE livres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    auteur VARCHAR(255) NOT NULL,
    categorie_id INT,
    etat ENUM('Disponible', 'Indisponible') DEFAULT 'Disponible',
    description TEXT,
    couverture VARCHAR(255), -- URL ou chemin vers l'image
    prix DECIMAL(10, 2) DEFAULT 0,
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Table réservations
CREATE TABLE reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    livre_id INT NOT NULL,
    utilisateur_id INT NOT NULL,
    date_reservation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    statut ENUM('En attente', 'Confirmée', 'Annulée') DEFAULT 'En attente',
    FOREIGN KEY (livre_id) REFERENCES livres(id) ON DELETE CASCADE,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
);

-- Table emprunts
CREATE TABLE emprunts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    livre_id INT NOT NULL,
    utilisateur_id INT NOT NULL,
    date_emprunt DATE DEFAULT CURRENT_DATE,
    date_retour DATE,
    statut ENUM('En cours', 'Retourné') DEFAULT 'En cours',
    FOREIGN KEY (livre_id) REFERENCES livres(id) ON DELETE CASCADE,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
);

-- Table événements
CREATE TABLE evenements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    date_event DATE NOT NULL,
    lieu VARCHAR(255) NOT NULL,
    organisateur VARCHAR(100),
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table panier
CREATE TABLE panier (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    livre_id INT NOT NULL,
    quantite INT DEFAULT 1,
    date_ajout TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (livre_id) REFERENCES livres(id) ON DELETE CASCADE
);

-- Ajouter des catégories
INSERT INTO categories (nom, description) VALUES
('Romance', 'Livres axés sur l’amour et les relations.'),
('Humour', 'Livres comiques et divertissants.'),
('Science', 'Livres scientifiques et techniques.'),
('Biographies', 'Histoires de vie inspirantes.');

-- Ajouter des livres
INSERT INTO livres (titre, auteur, categorie_id, etat, description, couverture, prix) VALUES
('Coincé avec M. Billionaire', 'D R E A M E R', 1, 'Disponible', 'Une histoire captivante...', '/images/book1.jpg', 12.99),
('Le Clown Perdu', 'Jean Rire', 2, 'Indisponible', 'Un livre hilarant...', '/images/book2.jpg', 9.99),
('Exploration scientifique', 'Marie Curie', 3, 'Disponible', 'Découvertes révolutionnaires...', '/images/book3.jpg', 15.99),
('Ma Vie Inspirante', 'Nelson Mandela', 4, 'Disponible', 'Un voyage inspirant...', '/images/book4.jpg', 18.99);

-- Ajouter des utilisateurs
INSERT INTO utilisateurs (prenom, nom, email, password, role) VALUES
('Alice', 'Dupont', 'alice@example.com', SHA2('password123', 256), 'Utilisateur'),
('Bob', 'Martin', 'bob@example.com', SHA2('adminpassword', 256), 'Admin');

-- Ajouter des événements
INSERT INTO evenements (titre, description, date_event, lieu, organisateur) VALUES
('Club de Lecture', 'Discussion autour du roman XYZ.', '2024-05-01', 'Salle 101', 'Bibliothèque'),
('Conférence sur la Science', 'Exploration des récentes découvertes.', '2024-06-15', 'Auditorium', 'Marie Curie Foundation'),
('Atelier d’Écriture', 'Perfectionnez vos compétences en écriture.', '2024-07-20', 'Salle 202', 'Writers Guild');
