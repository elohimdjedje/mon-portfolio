<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Événements - Ma Bibliothèque";
include 'admin_header.php'; // Header Admin
include 'db.php'; // Connexion à la base de données
?>

<main class="container py-5">
    <h1 class="text-center text-primary">Gérer les Événements</h1>

    <!-- Bouton Ajouter un Événement -->
    <div class="text-end mb-4">
        <a href="add_event.php" class="btn btn-primary rounded-pill">Ajouter un Événement</a>
    </div>

    <!-- Tableau des événements -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-primary">
                <tr>
                    <th>#</th>
                    <th>Titre</th>
                    <th>Date</th>
                    <th>Lieu</th>
                    <th>Organisateur</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $conn->prepare("SELECT * FROM evenements ORDER BY date_event DESC");
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['titre']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_event']); ?></td>
                            <td><?php echo htmlspecialchars($row['lieu']); ?></td>
                            <td><?php echo htmlspecialchars($row['organisateur']); ?></td>
                            <td>
                                <a href="edit_event.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Modifier</a>
                                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $row['id']; ?>">Supprimer</button>
                            </td>
                        </tr>

                        <!-- Modal de confirmation de suppression -->
                        <div class="modal fade" id="deleteModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-danger" id="deleteModalLabel">Confirmer la suppression</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Êtes-vous sûr de vouloir supprimer l'événement <strong><?php echo htmlspecialchars($row['titre']); ?></strong> ?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                        <form action="delete_event.php" method="POST">
                                            <input type="hidden" name="event_id" value="<?php echo $row['id']; ?>">
                                            <button type="submit" class="btn btn-danger">Supprimer</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>Aucun événement trouvé.</td></tr>";
                }

                $stmt->close();
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
