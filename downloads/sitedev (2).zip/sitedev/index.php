<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<!-- Corps du site -->
<main>
    <!-- Carrousel d'images -->
    <section id="carouselExample" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://via.placeholder.com/1500x500" class="d-block w-100" alt="Image 1">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded">
                    <h5>Nouveautés</h5>
                    <p>Découvrez les derniers livres ajoutés à notre catalogue.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://via.placeholder.com/1500x500" class="d-block w-100" alt="Image 2">
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded">
                    <h5>Événements à venir</h5>
                    <p>Participez à nos clubs de lecture et conférences.</p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Précédent</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Suivant</span>
        </button>
    </section>

    <!-- Section catégories -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="fw-bold mb-4">Explorez nos collections</h2>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="card bg-info text-white p-3 shadow">
                        <h4>Romans</h4>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-danger text-white p-3 shadow">
                        <h4>Science</h4>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white p-3 shadow">
                        <h4>Histoire</h4>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white p-3 shadow">
                        <h4>Biographies</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'footer.php'; // Inclusion du footer ?>
