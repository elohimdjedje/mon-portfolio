<?php
session_start();
$title = "Connexion Admin - Ma Bibliothèque";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="col-md-6 p-5 bg-white shadow-lg rounded">
            <h3 class="text-center text-primary mb-4">Connexion Administrateur</h3>
            
            <!-- Affichage des erreurs -->
            <?php if (isset($_SESSION['admin_error'])) : ?>
                <div class="alert alert-danger">
                    <?php 
                    echo htmlspecialchars($_SESSION['admin_error']);
                    unset($_SESSION['admin_error']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Formulaire de connexion -->
            <form action="admin_login_handler.php" method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label">Adresse Email</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Mot de Passe</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Se connecter</button>
            </form>
        </div>
    </div>
</body>
</html>
