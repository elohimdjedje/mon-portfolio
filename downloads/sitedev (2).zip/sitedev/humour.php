<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>
    <!-- Contenu spécifique à la page -->
    <main>
        <section class="py-5">
            <div class="container">
                <h2 class="fw-bold mb-4 text-center">Humour</h2>
                <!-- Insérez les livres ici -->
                <div class="row g-4">
                    <!-- Livre 1 -->
                    <div class="col-md-4">
                        <div class="book-card p-3 shadow-sm">
                            <a href="book-details-humour/book1.html" class="text-decoration-none text-dark">
                                <div class="d-flex">
                                    <img src="https://via.placeholder.com/80x120" alt="Livre 1" class="book-img me-3">
                                    <div>
                                        <h5 class="fw-bold">Le Clown Perdu</h5>
                                        <p class="text-muted mb-1">par <span class="fw-bold">Jean Rire</span></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>

                    <!-- Livre 2 -->
                    <div class="col-md-4">
                        <div class="book-card p-3 shadow-sm">
                            <a href="book-details-humour/book2.html" class="text-decoration-none text-dark">
                                <div class="d-flex">
                                    <img src="https://via.placeholder.com/80x120" alt="Livre 2" class="book-img me-3">
                                    <div>
                                        <h5 class="fw-bold">Blagues à part</h5>
                                        <p class="text-muted mb-1">par <span class="fw-bold">Sarah Fun</span></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; // Inclusion du footer ?>
    
</body>
</html>
