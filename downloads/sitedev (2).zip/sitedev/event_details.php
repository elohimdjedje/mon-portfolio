<?php
session_start();
include 'admin_header.php'; // Header Admin
include 'db.php'; // Connexion à la base de données

// Vérifier si l'ID de l'événement est passé en paramètre
if (!isset($_GET['id'])) {
    header("Location: manage_events.php");
    exit;
}

$event_id = $_GET['id'];

// Récupérer les détails de l'événement
$stmt = $conn->prepare("SELECT * FROM evenements WHERE id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: manage_events.php");
    exit;
}

$event = $result->fetch_assoc();
$stmt->close();
?>

<main class="container py-5">
    <h1 class="text-center text-primary"><?php echo htmlspecialchars($event['titre']); ?></h1>

    <div class="mt-4">
        <h3>Description</h3>
        <p><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>

        <h3>Informations principales</h3>
        <ul>
            <li><strong>Date :</strong> <?php echo htmlspecialchars($event['date_event']); ?></li>
            <li><strong>Lieu :</strong> <?php echo htmlspecialchars($event['lieu']); ?></li>
            <li><strong>Organisateur :</strong> <?php echo htmlspecialchars($event['organisateur']); ?></li>
        </ul>

        <a href="manage_events.php" class="btn btn-secondary mt-3">Retour à la liste des événements</a>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
