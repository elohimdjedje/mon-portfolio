<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Notifications - Ma Bibliothèque";
include 'admin_header.php';
include 'db.php';

// Récupérer les notifications
$result = $conn->query("SELECT * FROM notifications ORDER BY date_creation DESC");
?>

<main class="container py-5">
    <h1 class="text-center text-primary">Gérer les Notifications</h1>

    <?php if ($result->num_rows > 0): ?>
        <div class="list-group">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1"><?php echo htmlspecialchars($row['titre']); ?></h5>
                        <p class="mb-1 text-muted"><?php echo htmlspecialchars($row['description']); ?></p>
                        <small class="text-muted">Reçu le : <?php echo htmlspecialchars($row['date_creation']); ?></small>
                    </div>
                    <div>
                        <form action="mark_notification.php" method="POST" class="d-inline">
                            <input type="hidden" name="notification_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" class="btn btn-success btn-sm">Marquer comme lu</button>
                        </form>
                        <form action="delete_notification.php" method="POST" class="d-inline">
                            <input type="hidden" name="notification_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p class="text-center text-muted">Aucune notification disponible.</p>
    <?php endif; ?>
</main>

<?php include 'admin_footer.php'; ?>
