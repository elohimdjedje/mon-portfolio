<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Réservations - Admin";
include 'admin_header.php'; // Header spécifique à l'admin
include 'db.php'; // Connexion à la base de données
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Gérer les Réservations</h1>

    <?php
    // Récupérer les réservations depuis la base de données
    $sql = "SELECT r.id, l.titre, u.nom, u.email, r.date_reservation, r.statut
            FROM reservations r
            JOIN livres l ON r.livre_id = l.id
            JOIN utilisateurs u ON r.utilisateur_id = u.id
            ORDER BY r.date_reservation DESC";
    $result = $conn->query($sql);
    ?>

    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="table-primary">
                <tr>
                    <th>#</th>
                    <th>Livre</th>
                    <th>Utilisateur</th>
                    <th>Email</th>
                    <th>Date de Réservation</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['titre']); ?></td>
                            <td><?php echo htmlspecialchars($row['nom']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo $row['date_reservation']; ?></td>
                            <td>
                                <?php
                                if ($row['statut'] === 'En attente') {
                                    echo '<span class="badge bg-warning">En attente</span>';
                                } elseif ($row['statut'] === 'Confirmée') {
                                    echo '<span class="badge bg-success">Confirmée</span>';
                                } else {
                                    echo '<span class="badge bg-danger">Annulée</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo $row['id']; ?>">
                                    Détails
                                </button>

                                <form action="update_reservation.php" method="POST" class="d-inline">
                                    <input type="hidden" name="reservation_id" value="<?php echo $row['id']; ?>">
                                    <?php if ($row['statut'] === 'En attente') : ?>
                                        <button type="submit" name="confirm" class="btn btn-success btn-sm">Confirmer</button>
                                        <button type="submit" name="cancel" class="btn btn-danger btn-sm">Annuler</button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>

                        <!-- Modal Détails -->
                        <div class="modal fade" id="detailsModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="detailsModalLabel">Détails de la Réservation</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>Livre :</strong> <?php echo htmlspecialchars($row['titre']); ?></p>
                                        <p><strong>Utilisateur :</strong> <?php echo htmlspecialchars($row['nom']); ?></p>
                                        <p><strong>Email :</strong> <?php echo htmlspecialchars($row['email']); ?></p>
                                        <p><strong>Date de Réservation :</strong> <?php echo $row['date_reservation']; ?></p>
                                        <p><strong>Statut :</strong> <?php echo $row['statut']; ?></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>Aucune réservation trouvée.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
