<?php
session_start();

// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "bibliotheque");

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

// Récupérer les données
$livre_id = $_GET['id'];
$utilisateur_id = $_SESSION['utilisateur_id']; // Supposons que l'utilisateur est connecté

// Ajouter la réservation
$sql = "INSERT INTO reservations (livre_id, utilisateur_id) VALUES ($livre_id, $utilisateur_id)";
if ($conn->query($sql) === TRUE) {
    echo "Réservation ajoutée avec succès.";
    header("Location: mes-reservations.html"); // Redirection après succès
} else {
    echo "Erreur : " . $conn->error;
}

$conn->close();
?>
