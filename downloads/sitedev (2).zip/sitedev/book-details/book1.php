<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coincé avec M. Billionaire</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-white border-bottom shadow-sm py-3">
        <div class="container d-flex justify-content-between align-items-center">
            <!-- Logo -->
            <h1 class="m-0 text-primary fw-bold" style="font-size: 2rem;">📚 Ma Bibliothèque</h1>

            <!-- Barre de recherche -->
            <form class="d-flex align-items-center" style="flex: 1; margin: 0 20px;">
                <input type="text" class="form-control me-2 rounded-pill" placeholder="Rechercher un livre, auteur ou catégorie...">
                <button class="btn btn-outline-primary rounded-pill" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </form>

             <!-- Icône Panier -->
             <a href="cart.html" class="btn btn-outline-primary rounded-pill mx-2">
                <i class="fas fa-shopping-cart"></i>
            </a>

            <!-- Bouton S'inscrire -->
            <a href="#" class="btn btn-outline-primary rounded-pill" id="btn-inscrire">
                <i class="fas fa-user-circle"></i> S'inscrire
            </a>
        </div>
    </header>

    <!-- Barre de navigation -->
    <nav class="bg-light py-2 border-top">
        <div class="container d-flex justify-content-center">
            <ul class="nav position-relative">
                <li class="nav-item">
                    <a href="../index.html" class="nav-link text-dark px-3">Accueil</a>
                </li>
                <li class="nav-item">
                    <a href="../romance.html" class="nav-link text-dark px-3">Romance</a>
                </li>
                <li class="nav-item">
                    <a href="../humour.html" class="nav-link text-dark px-3">Humour</a>
                </li>
                <li class="nav-item">
                    <a href="../catalogue.html" class="nav-link text-dark px-3">Catalogue</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Corps de la page -->
    <div class="container py-5">
        <div class="row">
            <!-- Image du livre -->
            <div class="col-md-4">
                <img src="https://via.placeholder.com/200x300" alt="Coincé avec M. Billionaire" class="img-fluid shadow">
            </div>
            <!-- Détails du livre -->
            <div class="col-md-8">
                <h1>Coincé avec M. Billionaire</h1>
                <p class="text-muted">par <span class="fw-bold">D R E A M E R</span></p>
                <h5 class="mt-4">Résumé</h5>
                <p>
                    Louise, une belle comédienne, se retrouve seule avec son fils après une séparation...
                </p>
                <h5>À propos de ce livre</h5>
                <ul>
                    <li>186 pages</li>
                    <li>3-4 heures de lecture</li>
                    <li>50k mots</li>
                </ul>
                <h5 class="mt-4">Prix</h5>
                <p><span class="fw-bold text-danger">12,99 €</span></p>
                <a href="#" class="btn btn-danger">Ajouter au panier</a>
                <a href="#" class="btn btn-outline-secondary">Ajouter à ma liste d'envies</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <!-- Section À propos -->
                <div class="col-md-4">
                    <h5 class="fw-bold">À propos de nous</h5>
                    <p class="text-muted">
                        📚 Ma Bibliothèque est votre espace pour explorer, lire, et emprunter vos livres préférés. Nous nous engageons à rendre la lecture accessible à tous.
                    </p>
                </div>
    
                <!-- Section Liens utiles -->
                <div class="col-md-4">
                    <h5 class="fw-bold">Liens utiles</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.html" class="text-white text-decoration-none">Accueil</a></li>
                        <li><a href="romance.html" class="text-white text-decoration-none">Romance</a></li>
                        <li><a href="humour.html" class="text-white text-decoration-none">Humour</a></li>
                        <li><a href="services.html" class="text-white text-decoration-none">Services</a></li>
                        <li><a href="contact.html" class="text-white text-decoration-none">Contact</a></li>
                        <li><a href="cart.html" class="text-white text-decoration-none">Mon panier</a></li>
                    </ul>
                </div>
    
                <!-- Section Contact -->
                <div class="col-md-4">
                    <h5 class="fw-bold">Contactez-nous</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> 123 Rue de la Lecture, Paris</li>
                        <li><i class="fas fa-phone-alt me-2"></i> +33 1 23 45 67 89</li>
                        <li><i class="fas fa-envelope me-2"></i> contact@mabibliotheque.fr</li>
                    </ul>
    
                    <!-- Réseaux sociaux -->
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin fa-lg"></i></a>
                    </div>
                </div>
            </div>
    
            <hr class="my-4 text-muted">
    
            <!-- Section Copyright -->
            <div class="text-center">
                <p class="mb-0">&copy; 2024 Ma Bibliothèque. Tous droits réservés. | <a href="#" class="text-white text-decoration-none">Mentions légales</a></p>
            </div>
        </div>
    </footer>
    <?php include 'footer.php'; // Inclusion du footer ?>
</body>
</html>
