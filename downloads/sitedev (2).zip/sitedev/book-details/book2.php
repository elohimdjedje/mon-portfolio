<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FILLE DU PDG</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container py-5">
        <div class="row">
            <!-- Image du livre -->
            <div class="col-md-4">
                <img src="https://via.placeholder.com/200x300" alt="FILLE DU PDG" class="img-fluid shadow">
            </div>
            <!-- Détails du livre -->
            <div class="col-md-8">
                <h1>FILLE DU PDG</h1>
                <p class="text-muted">par <span class="fw-bold">Anushka</span></p>
                <h5 class="mt-4">Résumé</h5>
                <p>
                    Jenifer Martin, une jeune femme de Californie au grand cœur, découvre qu'elle est la fille cachée d'un puissant PDG. Entre les défis de sa nouvelle vie et une romance inattendue, Jenifer doit naviguer dans un monde rempli de secrets et de passions.
                </p>
                <h5>À propos de ce livre</h5>
                <ul>
                    <li>210 pages</li>
                    <li>4-5 heures de lecture</li>
                    <li>65k mots</li>
                </ul>
                <h5 class="mt-4">Prix</h5>
                <p><span class="fw-bold text-danger">13,99 €</span></p>
                <a href="#" class="btn btn-danger">Ajouter au panier</a>
                <a href="#" class="btn btn-outline-secondary">Ajouter à ma liste d'envies</a>
            </div>
        </div>
    </div>
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <!-- Section À propos -->
                <div class="col-md-4">
                    <h5 class="fw-bold">À propos de nous</h5>
                    <p class="text-muted">
                        📚 Ma Bibliothèque est votre espace pour explorer, lire, et emprunter vos livres préférés. Nous nous engageons à rendre la lecture accessible à tous.
                    </p>
                </div>
    
                <!-- Section Liens utiles -->
                <div class="col-md-4">
                    <h5 class="fw-bold">Liens utiles</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.html" class="text-white text-decoration-none">Accueil</a></li>
                        <li><a href="romance.html" class="text-white text-decoration-none">Romance</a></li>
                        <li><a href="humour.html" class="text-white text-decoration-none">Humour</a></li>
                        <li><a href="services.html" class="text-white text-decoration-none">Services</a></li>
                        <li><a href="contact.html" class="text-white text-decoration-none">Contact</a></li>
                        <li><a href="cart.html" class="text-white text-decoration-none">Mon panier</a></li>
                    </ul>
                </div>
    
                <!-- Section Contact -->
                <div class="col-md-4">
                    <h5 class="fw-bold">Contactez-nous</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> 123 Rue de la Lecture, Paris</li>
                        <li><i class="fas fa-phone-alt me-2"></i> +33 1 23 45 67 89</li>
                        <li><i class="fas fa-envelope me-2"></i> contact@mabibliotheque.fr</li>
                    </ul>
    
                    <!-- Réseaux sociaux -->
                    <div class="mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin fa-lg"></i></a>
                    </div>
                </div>
            </div>
    
            <hr class="my-4 text-muted">
    
            <!-- Section Copyright -->
            <div class="text-center">
                <p class="mb-0">&copy; 2024 Ma Bibliothèque. Tous droits réservés. | <a href="#" class="text-white text-decoration-none">Mentions légales</a></p>
            </div>
        </div>
    </footer>
    <?php include 'footer.php'; // Inclusion du footer ?>
</body>
</html>
