<?php
$title = "Inscription - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<div class="container-fluid d-flex justify-content-center align-items-center vh-100">
    <div class="row w-75 shadow-lg rounded">
        <!-- Section gauche -->
        <div class="col-md-6 bg-primary text-white d-flex flex-column justify-content-center align-items-center rounded-start">
            <div class="profile-img mb-4">
                <img src="https://via.placeholder.com/150" alt="Profile" class="rounded-circle border border-4 border-white">
            </div>
            <h3 class="fw-bold">Bienvenue à Ma Bibliothèque</h3>
            <p class="text-center mt-3">
                Inscrivez-vous pour accéder à nos fonctionnalités et découvrir un monde de lecture illimité.
            </p>
        </div>

        <!-- Section droite -->
        <div class="col-md-6 bg-white p-5 rounded-end">
            <h3 class="text-center mb-4 text-primary">Créer un compte</h3>
            <form action="inscription_handler.php" method="POST">
                <!-- Prénom et Nom -->
                <div class="row mb-3">
                    <div class="col">
                        <label for="prenom" class="form-label">Prénom</label>
                        <input 
                            type="text" 
                            class="form-control rounded-pill" 
                            name="prenom" 
                            id="prenom" 
                            placeholder="Entrez votre prénom" 
                            required>
                    </div>
                    <div class="col">
                        <label for="nom" class="form-label">Nom</label>
                        <input 
                            type="text" 
                            class="form-control rounded-pill" 
                            name="nom" 
                            id="nom" 
                            placeholder="Entrez votre nom" 
                            required>
                    </div>
                </div>

                <!-- Email -->
                <div class="mb-3">
                    <label for="email" class="form-label">Adresse Email</label>
                    <input 
                        type="email" 
                        class="form-control rounded-pill" 
                        name="email" 
                        id="email" 
                        placeholder="Entrez votre email" 
                        required>
                </div>

                <!-- Mot de passe -->
                <div class="mb-3">
                    <label for="password" class="form-label">Mot de Passe</label>
                    <input 
                        type="password" 
                        class="form-control rounded-pill" 
                        name="password" 
                        id="password" 
                        placeholder="Créez un mot de passe" 
                        required>
                </div>

                <!-- Bouton -->
                <button 
                    type="submit" 
                    class="btn btn-primary w-100 rounded-pill">
                    S'inscrire
                </button>

                <!-- Lien connexion -->
                <div class="text-center mt-3">
                    <p>Déjà inscrit ? 
                        <a href="connexion.php" class="text-primary fw-bold">Connectez-vous ici</a>.
                    </p>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; // Inclusion du footer ?>
