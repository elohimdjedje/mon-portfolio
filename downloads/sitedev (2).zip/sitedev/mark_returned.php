<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emprunt_id = $_POST['emprunt_id'];

    // Mettre à jour le statut de l'emprunt
    $stmt = $conn->prepare("UPDATE emprunts SET statut = 'Retourné', date_retour = NOW() WHERE id = ?");
    $stmt->bind_param("i", $emprunt_id);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Emprunt marqué comme retourné avec succès.";
    } else {
        $_SESSION['error_message'] = "Erreur lors de la mise à jour de l'emprunt.";
    }

    $stmt->close();
}

header("Location: manage_emprunts.php");
exit;
