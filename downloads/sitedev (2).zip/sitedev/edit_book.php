<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Modifier un Livre - Ma Bibliothèque";
include 'admin_header.php'; // Header spécifique pour l'admin
include 'db.php'; // Connexion à la base de données

// Récupérer l'ID du livre
if (!isset($_GET['id'])) {
    $_SESSION['error_message'] = "Aucun livre sélectionné pour modification.";
    header("Location: manage_books.php");
    exit;
}

$book_id = intval($_GET['id']);
$book_query = $conn->prepare("SELECT * FROM livres WHERE id = ?");
$book_query->bind_param("i", $book_id);
$book_query->execute();
$book_result = $book_query->get_result();

if ($book_result->num_rows === 0) {
    $_SESSION['error_message'] = "Livre introuvable.";
    header("Location: manage_books.php");
    exit;
}

$book = $book_result->fetch_assoc();

// Gérer la mise à jour des données
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'];
    $auteur = $_POST['auteur'];
    $categorie_id = $_POST['categorie'];
    $etat = $_POST['etat'];
    $prix = $_POST['prix'];
    $description = $_POST['description'];

    // Gérer l'upload de l'image si elle est modifiée
    $image_path = $book['couverture'];
    if (isset($_FILES['couverture']) && $_FILES['couverture']['error'] === UPLOAD_ERR_OK) {
        $image_path = 'uploads/' . basename($_FILES['couverture']['name']);
        move_uploaded_file($_FILES['couverture']['tmp_name'], $image_path);
    }

    // Mettre à jour les données dans la base
    $stmt = $conn->prepare("UPDATE livres SET titre = ?, auteur = ?, categorie_id = ?, etat = ?, description = ?, couverture = ?, prix = ? WHERE id = ?");
    $stmt->bind_param("ssisssdi", $titre, $auteur, $categorie_id, $etat, $description, $image_path, $prix, $book_id);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Livre mis à jour avec succès.";
        header("Location: manage_books.php");
        exit;
    } else {
        $error_message = "Erreur lors de la mise à jour du livre : " . $conn->error;
    }
}
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Modifier un Livre</h1>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <form action="edit_book.php?id=<?php echo $book_id; ?>" method="POST" enctype="multipart/form-data">
        <div class="row mb-3">
            <!-- Titre -->
            <div class="col-md-6">
                <label for="titre" class="form-label">Titre</label>
                <input type="text" class="form-control" id="titre" name="titre" value="<?php echo htmlspecialchars($book['titre']); ?>" required>
            </div>
            <!-- Auteur -->
            <div class="col-md-6">
                <label for="auteur" class="form-label">Auteur</label>
                <input type="text" class="form-control" id="auteur" name="auteur" value="<?php echo htmlspecialchars($book['auteur']); ?>" required>
            </div>
        </div>

        <div class="row mb-3">
            <!-- Catégorie -->
            <div class="col-md-6">
                <label for="categorie" class="form-label">Catégorie</label>
                <select class="form-select" id="categorie" name="categorie" required>
                    <?php
                    $categories = $conn->query("SELECT * FROM categories");
                    while ($row = $categories->fetch_assoc()) {
                        $selected = $book['categorie_id'] == $row['id'] ? 'selected' : '';
                        echo "<option value='" . $row['id'] . "' $selected>" . htmlspecialchars($row['nom']) . "</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- Statut -->
            <div class="col-md-6">
                <label for="etat" class="form-label">Statut</label>
                <select class="form-select" id="etat" name="etat" required>
                    <option value="Disponible" <?php echo $book['etat'] === 'Disponible' ? 'selected' : ''; ?>>Disponible</option>
                    <option value="Indisponible" <?php echo $book['etat'] === 'Indisponible' ? 'selected' : ''; ?>>Indisponible</option>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <!-- Prix -->
            <div class="col-md-6">
                <label for="prix" class="form-label">Prix (€)</label>
                <input type="number" class="form-control" id="prix" name="prix" step="0.01" value="<?php echo htmlspecialchars($book['prix']); ?>" required>
            </div>
            <!-- Couverture -->
            <div class="col-md-6">
                <label for="couverture" class="form-label">Image de Couverture</label>
                <input type="file" class="form-control" id="couverture" name="couverture" accept="image/*">
                <small class="text-muted">Actuelle : <a href="<?php echo $book['couverture']; ?>" target="_blank">Voir</a></small>
            </div>
        </div>

        <!-- Description -->
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($book['description']); ?></textarea>
        </div>

        <!-- Bouton Modifier -->
        <div class="text-end">
            <button type="submit" class="btn btn-success">Mettre à jour</button>
        </div>
    </form>
</main>

<?php include 'admin_footer.php'; ?>
