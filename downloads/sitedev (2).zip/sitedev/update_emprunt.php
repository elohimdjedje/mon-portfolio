<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emprunt_id = $_POST['emprunt_id'];

    if (isset($_POST['retourner'])) {
        $stmt = $conn->prepare("UPDATE emprunts SET statut = 'Retourné', date_retour = CURRENT_DATE WHERE id = ?");
        $stmt->bind_param("i", $emprunt_id);
        $stmt->execute();
        $_SESSION['success_message'] = "Emprunt marqué comme retourné.";
    }

    header("Location: manage_emprunts.php");
    exit;
}
?>
