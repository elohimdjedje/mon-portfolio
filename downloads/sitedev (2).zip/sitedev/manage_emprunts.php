<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Emprunts - Ma Bibliothèque";
include 'admin_header.php';
include 'db.php';

// Message de succès ou d'erreur
if (isset($_SESSION['success_message'])) {
    echo "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    echo "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
    unset($_SESSION['error_message']);
}
?>

<main class="container py-5">
    <h1 class="text-center text-primary">Gérer les Emprunts</h1>
    <table class="table table-striped mt-4">
        <thead>
            <tr>
                <th>#</th>
                <th>Utilisateur</th>
                <th>Livre</th>
                <th>Date d'Emprunt</th>
                <th>Date de Retour</th>
                <th>Statut</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Récupérer les emprunts
            $stmt = $conn->prepare("SELECT e.id, u.nom, l.titre, e.date_emprunt, e.date_retour, e.statut 
                                    FROM emprunts e
                                    JOIN utilisateurs u ON e.utilisateur_id = u.id
                                    JOIN livres l ON e.livre_id = l.id
                                    ORDER BY e.date_emprunt DESC");
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['nom']); ?></td>
                    <td><?php echo htmlspecialchars($row['titre']); ?></td>
                    <td><?php echo htmlspecialchars($row['date_emprunt']); ?></td>
                    <td><?php echo htmlspecialchars($row['date_retour']) ?: 'Non retourné'; ?></td>
                    <td>
                        <span class="badge <?php echo $row['statut'] === 'En cours' ? 'bg-warning' : 'bg-success'; ?>">
                            <?php echo $row['statut']; ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($row['statut'] === 'En cours') : ?>
                            <form action="mark_returned.php" method="POST" style="display:inline;">
                                <input type="hidden" name="emprunt_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" class="btn btn-success btn-sm">Marquer comme Retourné</button>
                            </form>
                        <?php else : ?>
                            <button class="btn btn-secondary btn-sm" disabled>Déjà Retourné</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php
            }
            $stmt->close();
            ?>
        </tbody>
    </table>
</main>

<?php include 'admin_footer.php'; ?>
