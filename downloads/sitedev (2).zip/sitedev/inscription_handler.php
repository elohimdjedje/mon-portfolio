<?php
include 'db.php'; // Inclure la connexion à la base de données

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = $conn->real_escape_string($_POST['prenom']);
    $nom = $conn->real_escape_string($_POST['nom']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Hacher le mot de passe avant de le stocker
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Préparer la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO utilisateurs (prenom, nom, email, password) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Erreur dans la requête SQL : " . $conn->error);
    }

    $stmt->bind_param("ssss", $prenom, $nom, $email, $hashed_password);

    // Exécuter la requête
    if ($stmt->execute()) {
        echo "Inscription réussie ! Vous pouvez maintenant vous connecter.";
        header("Location: connexion.php");
        exit();
    } else {
        echo "Erreur lors de l'inscription : " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
