<?php
$title = "Science-fiction - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<main class="py-5">
    <div class="container">
        <h2 class="fw-bold text-center mb-4 text-primary">Livres de Science-fiction</h2>
        <div class="row g-4">
            <?php
            // Inclure la connexion à la base de données
            include 'db.php';

            // Récupérer les livres de la catégorie "Science-fiction"
            $sql = "SELECT * FROM livres WHERE categorie = 'Science-fiction' AND statut = 'Disponible'";
            $result = $conn->query($sql);

            // Vérifier s'il y a des livres dans la catégorie
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-4">
                        <div class="book-card p-3 shadow-sm">
                            <a href="book-details.php?id=<?php echo $row['id']; ?>" class="text-decoration-none text-dark">
                                <div class="d-flex">
                                    <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['titre']; ?>" class="book-img me-3" style="width: 100px; height: 150px;">
                                    <div>
                                        <h5 class="fw-bold"><?php echo $row['titre']; ?></h5>
                                        <p class="text-muted mb-2">par <span class="fw-bold"><?php echo $row['auteur']; ?></span></p>
                                        <p class="text-muted small"><?php echo substr($row['description'], 0, 50); ?>...</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p class='text-center text-muted'>Aucun livre disponible dans cette catégorie pour le moment.</p>";
            }

            // Fermer la connexion
            $conn->close();
            ?>
        </div>
    </div>
</main>

<?php include 'footer.php'; // Inclusion du footer ?>
