<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Tableau de Bord Admin - Ma Bibliothèque";
include 'admin_header.php'; // Inclusion du header spécifique admin
include 'db.php'; // Connexion à la base de données
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Tableau de Bord Administrateur</h1>

    <!-- Statistiques en haut -->
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Total Livres</h5>
                    <p class="card-text fs-2 text-success">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM livres");
                        echo $result->fetch_assoc()['total'];
                        ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Utilisateurs Inscrits</h5>
                    <p class="card-text fs-2 text-info">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM utilisateurs");
                        echo $result->fetch_assoc()['total'];
                        ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Emprunts en cours</h5>
                    <p class="card-text fs-2 text-warning">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM emprunts WHERE statut = 'En cours'");
                        echo $result->fetch_assoc()['total'];
                        ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Réservations en attente</h5>
                    <p class="card-text fs-2 text-danger">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) AS total FROM reservations WHERE statut = 'En attente'");
                        echo $result->fetch_assoc()['total'];
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Sections fonctionnelles -->
    <div class="row g-4 mt-5">
        <!-- Gérer les Livres -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-primary">Gérer les Livres</h4>
                    <p class="card-text">
                        Ajouter, modifier ou supprimer des livres dans votre bibliothèque.
                    </p>
                    <a href="manage_books.php" class="btn btn-outline-primary w-100">Gérer les Livres</a>
                </div>
            </div>
        </div>

        <!-- Gérer les Utilisateurs -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-info">Gérer les Utilisateurs</h4>
                    <p class="card-text">
                        Voir, bloquer ou supprimer les utilisateurs inscrits sur le site.
                    </p>
                    <a href="manage_users.php" class="btn btn-outline-info w-100">Gérer les Utilisateurs</a>
                </div>
            </div>
        </div>

        <!-- Gérer les Réservations -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-warning">Gérer les Réservations</h4>
                    <p class="card-text">
                        Approuver ou annuler les réservations de livres effectuées par les utilisateurs.
                    </p>
                    <a href="manage_reservations.php" class="btn btn-outline-warning w-100">Gérer les Réservations</a>
                </div>
            </div>
        </div>

        <!-- Gérer les Emprunts -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-danger">Gérer les Emprunts</h4>
                    <p class="card-text">
                        Suivre les emprunts de livres en cours et gérer les retours.
                    </p>
                    <a href="manage_emprunts.php" class="btn btn-outline-danger w-100">Gérer les Emprunts</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Section supplémentaire -->
    <div class="row g-4 mt-5">
        <!-- Voir les Événements -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-success">Voir les Événements</h4>
                    <p class="card-text">
                        Gérer les événements organisés par la bibliothèque.
                    </p>
                    <a href="manage_events.php" class="btn btn-outline-success w-100">Voir les Événements</a>
                </div>
            </div>
        </div>

        <!-- Statistiques détaillées -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="card-title text-secondary">Statistiques</h4>
                    <p class="card-text">
                        Visualiser les statistiques détaillées sur les utilisateurs, les livres et les interactions.
                    </p>
                    <a href="statistics.php" class="btn btn-outline-secondary w-100">Voir les Statistiques</a>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
