<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Modifier un Événement - Ma Bibliothèque";
include 'admin_header.php';
include 'db.php';

// Vérifier si l'ID de l'événement est présent dans l'URL
if (isset($_GET['id'])) {
    $event_id = $_GET['id'];

    // Récupérer les détails de l'événement
    $stmt = $conn->prepare("SELECT * FROM evenements WHERE id = ?");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Vérifier si l'événement existe
    if ($result->num_rows > 0) {
        $event = $result->fetch_assoc();
    } else {
        $_SESSION['error_message'] = "Événement introuvable.";
        header("Location: manage_events.php");
        exit;
    }
} else {
    header("Location: manage_events.php");
    exit;
}

// Traitement du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $conn->real_escape_string($_POST['titre']);
    $description = $conn->real_escape_string($_POST['description']);
    $date_event = $_POST['date_event'];
    $lieu = $conn->real_escape_string($_POST['lieu']);
    $organisateur = $conn->real_escape_string($_POST['organisateur']);

    $stmt = $conn->prepare("UPDATE evenements SET titre = ?, description = ?, date_event = ?, lieu = ?, organisateur = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $titre, $description, $date_event, $lieu, $organisateur, $event_id);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Événement modifié avec succès.";
    } else {
        $_SESSION['error_message'] = "Erreur lors de la modification de l'événement.";
    }

    header("Location: manage_events.php");
    exit;
}
?>

<main class="container py-5">
    <h1 class="text-center text-primary">Modifier l'Événement</h1>

    <form action="edit_event.php?id=<?php echo $event_id; ?>" method="POST" class="mt-4">
        <div class="mb-3">
            <label for="titre" class="form-label">Titre de l'Événement</label>
            <input type="text" class="form-control" id="titre" name="titre" value="<?php echo htmlspecialchars($event['titre']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($event['description']); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="date_event" class="form-label">Date de l'Événement</label>
            <input type="date" class="form-control" id="date_event" name="date_event" value="<?php echo htmlspecialchars($event['date_event']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="lieu" class="form-label">Lieu</label>
            <input type="text" class="form-control" id="lieu" name="lieu" value="<?php echo htmlspecialchars($event['lieu']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="organisateur" class="form-label">Organisateur</label>
            <input type="text" class="form-control" id="organisateur" name="organisateur" value="<?php echo htmlspecialchars($event['organisateur']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Modifier l'Événement</button>
    </form>
</main>

<?php include 'admin_footer.php'; ?>