<?php
session_start();
include 'db.php'; // Connexion à la base de données

if (!isset($_GET['id'])) {
    header("Location: manage_loans.php");
    exit;
}

$loan_id = $_GET['id'];

$stmt = $conn->prepare("UPDATE emprunts SET statut = 'Retourné', date_retour = CURDATE() WHERE id = ?");
$stmt->bind_param("i", $loan_id);

if ($stmt->execute()) {
    $_SESSION['message'] = "Retour validé avec succès.";
} else {
    $_SESSION['message'] = "Erreur lors de la validation du retour.";
}

$stmt->close();
header("Location: manage_loans.php");
exit;
