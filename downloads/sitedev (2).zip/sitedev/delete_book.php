<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include 'db.php'; // Connexion à la base de données

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['book_id'])) {
        $book_id = intval($_POST['book_id']);

        // Supprimer le livre de la base de données
        $stmt = $conn->prepare("DELETE FROM livres WHERE id = ?");
        $stmt->bind_param("i", $book_id);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Le livre a été supprimé avec succès.";
        } else {
            $_SESSION['error_message'] = "Erreur lors de la suppression du livre : " . $conn->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Aucun livre sélectionné pour suppression.";
    }

    header("Location: manage_books.php");
    exit;
}

// Si le script est appelé sans méthode POST, rediriger
header("Location: manage_books.php");
exit;
