<?php
$title = "Détails de l'Événement - Conférence"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>

<main class="py-5">
    <div class="container">
        <!-- En-tête de l'événement -->
        <div class="event-header text-center mb-4">
            <img src="https://via.placeholder.com/800x400" alt="Événement" class="img-fluid rounded shadow">
            <h2 class="fw-bold mt-3 text-primary">Conférence : L'avenir des bibliothèques</h2>
        </div>

        <!-- Informations principales -->
        <div class="event-details bg-light p-4 rounded shadow">
            <h3 class="fw-bold">Informations principales</h3>
            <ul class="list-unstyled">
                <li class="mb-2">
                    <i class="fas fa-calendar-alt text-primary"></i> 
                    <strong>Date :</strong> 20 Décembre 2024
                </li>
                <li class="mb-2">
                    <i class="fas fa-map-marker-alt text-primary"></i> 
                    <strong>Lieu :</strong> 456 Avenue des Innovations, Paris
                </li>
                <li class="mb-2">
                    <i class="fas fa-clock text-primary"></i> 
                    <strong>Durée :</strong> 3 heures
                </li>
            </ul>
        </div>

        <!-- Description -->
        <div class="event-description mt-4">
            <h3 class="fw-bold">Description</h3>
            <p>
                Explorez les innovations technologiques et leurs impacts sur les bibliothèques. 
                Découvrez comment ces espaces évoluent pour répondre aux besoins de la génération numérique.
            </p>
        </div>

        <!-- Bouton d'inscription -->
        <div class="text-center mt-4">
            <a href="event-register.php?event_id=2" class="btn btn-primary rounded-pill px-5">
                S'inscrire à l'événement
            </a>
        </div>
    </div>
</main>

<?php include 'footer.php'; // Inclusion du footer ?>
