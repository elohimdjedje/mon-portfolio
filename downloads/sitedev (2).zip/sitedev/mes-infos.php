<?php
$title = "Mes Infos - Ma Bibliothèque";
include 'header.php';
include 'db.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['utilisateur_id'])) {
    header("Location: connexion.php");
    exit();
}

// Récupérer les informations de l'utilisateur
$stmt = $conn->prepare("SELECT prenom, nom, email, date_inscription FROM utilisateurs WHERE id = ?");
$stmt->bind_param("i", $_SESSION['utilisateur_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>

<main class="container py-5">
    <h2 class="fw-bold text-center">Mes Informations</h2>
    <div class="card shadow p-4">
        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($user['prenom']); ?></p>
        <p><strong>Nom :</strong> <?php echo htmlspecialchars($user['nom']); ?></p>
        <p><strong>Email :</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        <p><strong>Date d'inscription :</strong> <?php echo htmlspecialchars($user['date_inscription']); ?></p>
    </div>
</main>

<?php include 'footer.php'; ?>
