<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Ajouter un Événement - Ma Bibliothèque";
include 'admin_header.php'; // Header Admin
include 'db.php'; // Connexion à la base de données

// Traitement du formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $date_event = $_POST['date_event'];
    $lieu = $_POST['lieu'];
    $organisateur = $_POST['organisateur'];

    // Préparer la requête
    $stmt = $conn->prepare("INSERT INTO evenements (titre, description, date_event, lieu, organisateur) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $titre, $description, $date_event, $lieu, $organisateur);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Événement ajouté avec succès.";
        header("Location: manage_events.php");
        exit;
    } else {
        $error_message = "Erreur lors de l'ajout de l'événement : " . $conn->error;
    }
}
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Ajouter un Événement</h1>

    <!-- Affichage des messages d'erreur ou de succès -->
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <form action="add_event.php" method="POST" class="shadow-lg p-4 bg-white rounded">
        <div class="mb-3">
            <label for="titre" class="form-label">Titre de l'Événement</label>
            <input type="text" name="titre" id="titre" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" id="description" class="form-control" rows="5" required></textarea>
        </div>

        <div class="mb-3">
            <label for="date_event" class="form-label">Date de l'Événement</label>
            <input type="date" name="date_event" id="date_event" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="lieu" class="form-label">Lieu</label>
            <input type="text" name="lieu" id="lieu" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="organisateur" class="form-label">Organisateur</label>
            <input type="text" name="organisateur" id="organisateur" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Ajouter l'Événement</button>
    </form>
</main>

<?php include 'admin_footer.php'; ?>
