<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>
    <!-- Section Événements -->
    <main class="py-5">
        <div class="container">
            <h2 class="fw-bold text-center mb-4">Événements à venir</h2>
            <div class="row g-4">
                <!-- Événement 1 -->
                <div class="col-md-4">
                    <div class="card event-card">
                        <a href="event-details.php" class="text-decoration-none">
                            <img src="https://via.placeholder.com/350x200" class="card-img-top" alt="Événement 1">
                            <div class="event-card-body">
                                <h5 class="card-title fw-bold">Club de lecture : Littérature française</h5>
                                <p class="event-date">📅 15 Décembre 2024</p>
                                <p class="card-text">
                                    Rejoignez-nous pour discuter de nos romans français préférés avec d'autres passionnés de lecture.
                                </p>
                                <span class="btn btn-primary btn-sm">Voir les détails</span>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Événement 2 -->
                <div class="col-md-4">
                    <div class="card event-card">
                        <a href="event-details2.php" class="text-decoration-none">
                            <img src="https://via.placeholder.com/350x200" class="card-img-top" alt="Événement 2">
                            <div class="event-card-body">
                                <h5 class="card-title fw-bold">Conférence : L'avenir des bibliothèques</h5>
                                <p class="event-date">📅 20 Décembre 2024</p>
                                <p class="card-text">
                                    Découvrez les innovations technologiques qui redéfinissent le rôle des bibliothèques dans nos vies.
                                </p>
                                <span class="btn btn-primary btn-sm">Voir les détails</span>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Événement 3 -->
                <div class="col-md-4">
                    <div class="card event-card">
                        <a href="event-details3.php" class="text-decoration-none">
                            <img src="https://via.placeholder.com/350x200" class="card-img-top" alt="Événement 3">
                            <div class="event-card-body">
                                <h5 class="card-title fw-bold">Atelier d'écriture : Créer un roman</h5>
                                <p class="event-date">📅 25 Décembre 2024</p>
                                <p class="card-text">
                                    Apprenez les bases de l'écriture créative avec notre atelier interactif et pratique.
                                </p>
                                <span class="btn btn-primary btn-sm">Voir les détails</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; // Inclusion du footer ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
