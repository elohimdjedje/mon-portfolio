<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Ajouter un Livre - Ma Bibliothèque";
include 'admin_header.php'; // Header spécifique pour l'admin
include 'db.php'; // Connexion à la base de données

// Gérer la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'];
    $auteur = $_POST['auteur'];
    $categorie_id = $_POST['categorie'];
    $etat = $_POST['etat'];
    $prix = $_POST['prix'];
    $description = $_POST['description'];

    // Gérer l'image de couverture
    $image_path = null;
    if (isset($_FILES['couverture']) && $_FILES['couverture']['error'] === UPLOAD_ERR_OK) {
        $image_path = 'uploads/' . basename($_FILES['couverture']['name']);
        move_uploaded_file($_FILES['couverture']['tmp_name'], $image_path);
    }

    $stmt = $conn->prepare("INSERT INTO livres (titre, auteur, categorie_id, etat, description, couverture, prix) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisssd", $titre, $auteur, $categorie_id, $etat, $description, $image_path, $prix);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Livre ajouté avec succès.";
        header("Location: manage_books.php");
        exit;
    } else {
        $error_message = "Erreur lors de l'ajout du livre : " . $conn->error;
    }
}
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Ajouter un Livre</h1>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <form action="add_book.php" method="POST" enctype="multipart/form-data">
        <div class="row mb-3">
            <!-- Titre -->
            <div class="col-md-6">
                <label for="titre" class="form-label">Titre</label>
                <input type="text" class="form-control" id="titre" name="titre" required>
            </div>
            <!-- Auteur -->
            <div class="col-md-6">
                <label for="auteur" class="form-label">Auteur</label>
                <input type="text" class="form-control" id="auteur" name="auteur" required>
            </div>
        </div>

        <div class="row mb-3">
            <!-- Catégorie -->
            <div class="col-md-6">
                <label for="categorie" class="form-label">Catégorie</label>
                <select class="form-select" id="categorie" name="categorie" required>
                    <option value="" disabled selected>Choisissez une catégorie</option>
                    <?php
                    $result = $conn->query("SELECT * FROM categories");
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . htmlspecialchars($row['nom']) . "</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- Statut -->
            <div class="col-md-6">
                <label for="etat" class="form-label">Statut</label>
                <select class="form-select" id="etat" name="etat" required>
                    <option value="Disponible">Disponible</option>
                    <option value="Indisponible">Indisponible</option>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <!-- Prix -->
            <div class="col-md-6">
                <label for="prix" class="form-label">Prix (€)</label>
                <input type="number" class="form-control" id="prix" name="prix" step="0.01" required>
            </div>
            <!-- Couverture -->
            <div class="col-md-6">
                <label for="couverture" class="form-label">Image de Couverture</label>
                <input type="file" class="form-control" id="couverture" name="couverture" accept="image/*">
            </div>
        </div>

        <!-- Description -->
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
        </div>

        <!-- Bouton Ajouter -->
        <div class="text-end">
            <button type="submit" class="btn btn-primary">Ajouter le Livre</button>
        </div>
    </form>
</main>

<?php include 'admin_footer.php'; ?>
