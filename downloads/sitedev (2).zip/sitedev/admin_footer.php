<footer class="bg-dark text-white py-4 mt-5">
    <div class="container text-center">
        <p>&copy; 2024 Admin - Ma Bibliothèque. Tous droits réservés.</p>
    </div>
</footer>
</body>
</html>
