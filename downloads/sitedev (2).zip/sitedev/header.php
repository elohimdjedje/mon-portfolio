<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Ma Bibliothèque'; ?></title>
    <!-- Liens CSS et JS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <!-- Bootstrap JS et Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!-- Header -->
    <header class="bg-white border-bottom shadow-sm py-3">
        <div class="container d-flex justify-content-between align-items-center">
            <!-- Logo -->
            <h1 class="m-0 text-primary fw-bold" style="font-size: 2rem;">📚 Ma Bibliothèque</h1>
    
            <!-- Barre de recherche -->
            <form class="d-flex align-items-center" style="flex: 1; margin: 0 20px;">
                <input type="text" class="form-control me-2 rounded-pill" placeholder="Rechercher un livre, auteur ou catégorie...">
                <button class="btn btn-outline-primary rounded-pill" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </form>
    
            <!-- Icône Panier -->
            <a href="cart.php" class="btn btn-outline-primary rounded-pill mx-2">
                <i class="fas fa-shopping-cart"></i>
            </a>
    
            <!-- Mon Compte ou S'inscrire -->
            <?php if (isset($_SESSION['utilisateur_id'])): ?>
                <div class="dropdown">
                    <button 
                        class="btn btn-outline-primary rounded-pill dropdown-toggle" 
                        id="btn-mon-compte" 
                        data-bs-toggle="dropdown" 
                        aria-expanded="false"
                    >
                        Mon Compte
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="btn-mon-compte">
                        <li><a class="dropdown-item" href="mes_infos.php">Mes Infos</a></li>
                        <li><a class="dropdown-item" href="mes_emprunts.php">Emprunts en cours</a></li>
                        <li><a class="dropdown-item" href="mes_achats.php">Livres achetés</a></li>
                        <li><a class="dropdown-item" href="mes_reservations.php">Réservations</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="deconnexion.php">Se déconnecter</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <!-- S'inscrire (si non connecté) -->
                <a href="inscription.php" class="btn btn-outline-primary rounded-pill" id="btn-inscrire">
                    <i class="fas fa-user-circle"></i> S'inscrire
                </a>
            <?php endif; ?>
        </div>
    </header>
    
    <!-- Barre de navigation -->
    <nav class="bg-light py-2 border-top">
        <div class="container d-flex justify-content-center">
            <ul class="nav position-relative">
                <li class="nav-item">
                    <a href="index.php" class="nav-link text-dark px-3">Accueil</a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link text-dark px-3 dropdown-toggle" id="catalogue-link">Catalogue</a>
                    <!-- Encoche affichée au survol -->
                    <div class="dropdown-menu shadow" id="catalogue-dropdown">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="fw-bold">PARCOURIR</h6>
                                <ul class="list-unstyled">
                                    <li><a href="romance.php" class="dropdown-item">Romance</a></li>
                                    <li><a href="fanfiction.php" class="dropdown-item">Fanfiction</a></li>
                                    <li><a href="fiction-historique.php" class="dropdown-item">Fiction historique</a></li>
                                    <li><a href="humour.php" class="dropdown-item">Humour</a></li>
                                    <li><a href="eclairage-diversie.php" class="dropdown-item">Éclairage diversifié</a></li>
                                    <li><a href="science-fiction.php" class="dropdown-item">Science-fiction</a></li>
                                    <li><a href="non-fiction.php" class="dropdown-item">Non-fiction</a></li>
                                    <li><a href="nouvel-adulte.php" class="dropdown-item">Nouvel adulte</a></li>
                                    <li><a href="paranormal.php" class="dropdown-item">Paranormal</a></li>
                                    <li><a href="horreur.php" class="dropdown-item">Horreur</a></li>
                                    <li><a href="mystere.php" class="dropdown-item">Mystère</a></li>
                                    <li><a href="poesie.php" class="dropdown-item">Poésie</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="events.php" class="nav-link text-dark px-3">Événements</a>
                </li>
                <li class="nav-item">
                    <a href="services.php" class="nav-link text-dark px-3">Services</a>
                </li>
                <li class="nav-item">
                    <a href="contact.php" class="nav-link text-dark px-3">Contact</a>
                </li>
            </ul>
        </div>
    </nav>
</body>
</html>
