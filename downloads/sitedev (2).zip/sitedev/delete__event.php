<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['event_id'])) {
    $event_id = $_POST['event_id'];

    $stmt = $conn->prepare("DELETE FROM evenements WHERE id = ?");
    $stmt->bind_param("i", $event_id);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Événement supprimé avec succès.";
    } else {
        $_SESSION['error_message'] = "Erreur lors de la suppression.";
    }

    $stmt->close();
}

header("Location: manage_events.php");
exit;
?>
