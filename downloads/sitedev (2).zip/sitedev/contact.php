<?php
$title = "Accueil - Ma Bibliothèque"; // Titre dynamique pour le header
include 'header.php'; // Inclusion du header
?>
    <!-- Section Contact -->
    <main>
        <section class="py-5 bg-light">
            <div class="container">
                <h2 class="fw-bold text-center mb-4">Contactez-nous</h2>
                <div class="row g-4">
                    <!-- Formulaire de contact -->
                    <div class="col-md-6">
                        <h5 class="fw-bold">Envoyez-nous un message</h5>
                        <form action="#" method="POST" class="p-4 bg-white shadow-sm rounded">
                            <div class="mb-3">
                                <label for="name" class="form-label">Votre nom</label>
                                <input type="text" class="form-control rounded-pill" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Votre email</label>
                                <input type="email" class="form-control rounded-pill" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label">Message</label>
                                <textarea class="form-control rounded" id="message" name="message" rows="5" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary rounded-pill w-100">Envoyer</button>
                        </form>
                    </div>

                    <!-- Informations générales -->
                    <div class="col-md-6">
                        <h5 class="fw-bold">Nos coordonnées</h5>
                        <p>📚 Ma Bibliothèque</p>
                        <p><i class="fas fa-map-marker-alt me-2"></i> 123 Rue de la Lecture, Paris</p>
                        <p><i class="fas fa-phone-alt me-2"></i> +33 1 23 45 67 89</p>
                        <p><i class="fas fa-envelope me-2"></i> contact@mabibliotheque.fr</p>

                        <!-- Carte Google Maps -->
                        <div class="mt-4">
                            <iframe 
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2624.9992878810923!2d2.294481315674301!3d48.85884407928744!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e671d877dd3e4b%3A0x408ab2ae4c6e950!2sEiffel+Tower!5e0!3m2!1sen!2sfr!4v1635246201931!5m2!1sen!2sfr" 
                                width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; // Inclusion du footer ?>

</body>
</html>
