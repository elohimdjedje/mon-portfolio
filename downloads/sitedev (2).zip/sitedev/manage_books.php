<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Livres - Ma Bibliothèque";
include 'admin_header.php'; // Header spécifique pour l'admin
include 'db.php'; // Connexion à la base de données
?>

<main class="container py-5">
    <h1 class="text-center text-primary mb-4">Gérer les Livres</h1>

    <!-- Bouton Ajouter un Livre -->
    <div class="text-end mb-4">
        <a href="add_book.php" class="btn btn-success">Ajouter un Livre</a>
    </div>

    <!-- Liste des Livres -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-primary">
                <tr>
                    <th>#</th>
                    <th>Titre</th>
                    <th>Auteur</th>
                    <th>Catégorie</th>
                    <th>Statut</th>
                    <th>Prix</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Requête pour récupérer les livres
                $sql = "SELECT livres.id, livres.titre, livres.auteur, categories.nom AS categorie, livres.etat, livres.prix 
                        FROM livres 
                        LEFT JOIN categories ON livres.categorie_id = categories.id 
                        ORDER BY livres.date_ajout DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['titre']); ?></td>
                            <td><?php echo htmlspecialchars($row['auteur']); ?></td>
                            <td><?php echo htmlspecialchars($row['categorie'] ?? 'Non défini'); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $row['etat'] === 'Disponible' ? 'success' : 'danger'; ?>">
                                    <?php echo $row['etat']; ?>
                                </span>
                            </td>
                            <td><?php echo number_format($row['prix'], 2); ?> €</td>
                            <td>
                                <a href="edit_book.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Modifier</a>
                                <a href="delete_book.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce livre ?');">Supprimer</a>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="7" class="text-center">Aucun livre trouvé.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <!-- Bouton Supprimer -->
<form action="delete_book.php" method="POST" class="d-inline">
    <input type="hidden" name="book_id" value="<?php echo $row['id']; ?>">
    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce livre ?');">
        Supprimer
    </button>
</form>
<?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo htmlspecialchars($row['id']); ?></td>
        <td><?php echo htmlspecialchars($row['titre']); ?></td>
        <td><?php echo htmlspecialchars($row['auteur']); ?></td>
        <td><?php echo htmlspecialchars($row['categorie']); ?></td>
        <td>
            <!-- Bouton Supprimer -->
            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $row['id']; ?>">
                Supprimer
            </button>

            <!-- Modal -->
            <div class="modal fade" id="deleteModal<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title text-danger" id="deleteModalLabel">Confirmer la suppression</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Êtes-vous sûr de vouloir supprimer le livre <strong><?php echo htmlspecialchars($row['titre']); ?></strong> ?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            <form action="delete_book.php" method="POST">
                                <input type="hidden" name="book_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
<?php endwhile; ?>


</main>

<?php include 'admin_footer.php'; ?>
