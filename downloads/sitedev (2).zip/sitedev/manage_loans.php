<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$title = "Gérer les Emprunts - Ma Bibliothèque";
include 'admin_header.php'; // Header Admin
include 'db.php'; // Connexion à la base de données
?>

<main class="container py-5">
    <h1 class="text-center text-primary">Gérer les Emprunts</h1>
    <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-info text-center">
        <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
    </div>
<?php endif; ?>

    <div class="table-responsive mt-4">
        <table class="table table-striped table-bordered">
            <thead class="table-primary">
                <tr>
                    <th>#</th>
                    <th>Utilisateur</th>
                    <th>Livre</th>
                    <th>Date d'Emprunt</th>
                    <th>Date de Retour</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $conn->prepare("SELECT e.id, u.nom, u.prenom, l.titre, e.date_emprunt, e.date_retour, e.statut 
                                        FROM emprunts e
                                        JOIN utilisateurs u ON e.utilisateur_id = u.id
                                        JOIN livres l ON e.livre_id = l.id
                                        ORDER BY e.date_emprunt DESC");
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['prenom'] . " " . $row['nom']); ?></td>
                            <td><?php echo htmlspecialchars($row['titre']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_emprunt']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_retour'] ?? 'N/A'); ?></td>
                            <td>
                                <span class="badge <?php echo $row['statut'] === 'En cours' ? 'bg-warning' : 'bg-success'; ?>">
                                    <?php echo htmlspecialchars($row['statut']); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($row['statut'] === 'En cours'): ?>
                                    <a href="return_loan.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Valider Retour</a>
                                <?php else: ?>
                                    <span class="text-muted">Retour Validé</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>Aucun emprunt trouvé.</td></tr>";
                }

                $stmt->close();
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php include 'admin_footer.php'; ?>
