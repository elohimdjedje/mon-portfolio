<?php
$title = "Mes Réservations - Ma Bibliothèque";
include 'header.php';
include 'db.php';

if (!isset($_SESSION['utilisateur_id'])) {
    header("Location: connexion.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT l.titre, r.date_reservation, r.statut 
    FROM reservations r 
    JOIN livres l ON r.livre_id = l.id 
    WHERE r.utilisateur_id = ?");
$stmt->bind_param("i", $_SESSION['utilisateur_id']);
$stmt->execute();
$result = $stmt->get_result();
?>

<main class="container py-5">
    <h2 class="fw-bold text-center">Mes Réservations</h2>
    <?php if ($result->num_rows > 0): ?>
        <ul class="list-group">
            <?php while ($row = $result->fetch_assoc()): ?>
                <li class="list-group-item">
                    <strong><?php echo htmlspecialchars($row['titre']); ?></strong>
                    <br>
                    Date de réservation : <?php echo htmlspecialchars($row['date_reservation']); ?>
                    <br>
                    Statut : <?php echo htmlspecialchars($row['statut']); ?>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p class="text-center text-muted">Aucune réservation en cours.</p>
    <?php endif; ?>
</main>

<?php include 'footer.php'; ?>
