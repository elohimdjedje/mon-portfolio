import pandas as pd
import numpy as np
from rich.console import Console
from rich.table import Table

# 📌 Charger les données extraites
df = pd.read_csv("iphones_cleaned.csv")

# 🧼 Nettoyage : Suppression des espaces inutiles dans les noms
df["name"] = df["name"].str.replace(r"\s+", " ", regex=True).str.strip()

# 🔢 Conversion des types :
df["price"] = pd.to_numeric(df["price"], errors="coerce")  # Convertir prix en float
df["reviews"] = pd.to_numeric(df["reviews"], errors="coerce").fillna(0).astype(int)  # Avis en int

# 🧐 Gestion des valeurs manquantes :
df["price"].fillna(df["price"].median(), inplace=True)  # Remplacement des prix manquants par la médiane

# 🎯 Ajout de colonnes utiles :
df["price_category"] = np.where(df["price"] > 1000, "Haut de gamme",
                                np.where(df["price"] > 700, "Moyenne gamme", "Entrée de gamme"))

# 🔄 Normalisation des catégories (ex: tout en minuscules)
df["category"] = df["category"].str.lower()

# 📊 Affichage avec Rich
console = Console()
table = Table(title="📊 Nettoyage et Préparation des Données", style="bold cyan")

table.add_column("Name", style="bold magenta", min_width=40)
table.add_column("Price (€)", justify="right", style="yellow", min_width=10)
table.add_column("Category", style="green", min_width=15)
table.add_column("Price Range", style="blue", min_width=15)
table.add_column("Reviews", justify="center", style="red", min_width=8)

for _, row in df.head(15).iterrows():
    table.add_row(row["name"], f"{row['price']:.2f}", row["category"], row["price_category"], str(row["reviews"]))

console.print(table)

# 💾 Sauvegarde du fichier nettoyé
df.to_csv("iphones_final_cleaned.csv", index=False)
