import pandas as pd
import matplotlib.pyplot as plt
import os
from io import StringIO

# 📌 Charger les données
data = """
name,price,category,link,reviews
Smartphone APPLE iPhone 11 64Go,299.99,iPhone,https://www.boulanger.com/ref/1203834,10
Smartphone APPLE iPhone 12 128Go,399.99,iPhone,https://www.boulanger.com/ref/1217025,20
Smartphone APPLE iPhone 13 128Go,480.93,iPhone,https://www.boulanger.com/ref/1200036,30
Smartphone APPLE iPhone 14 128Go,694.99,iPhone,https://www.boulanger.com/ref/1184028,25
Smartphone APPLE iPhone 15 128Go,799.0,iPhone,https://www.boulanger.com/ref/1196258,40
Smartphone APPLE iPhone 16 128Go,910.0,iPhone,https://www.boulanger.com/ref/1211551,35
Smartphone APPLE iPhone 16 Pro 256Go,1299.99,iPhone,https://www.boulanger.com/ref/1211547,50
Smartphone APPLE iPhone 15 Pro Max 1To,1499.99,iPhone,https://www.boulanger.com/ref/1196374,60
"""

df = pd.read_csv(StringIO(data))

# 📌 Moyenne des prix par modèle
df["model"] = df["name"].str.extract(r'(iPhone \d+ \S+)')  # Extraire le modèle (ex. iPhone 11 64Go)
avg_price = df.groupby("model")["price"].mean().sort_values()

# 📊 Création du Barplot
plt.figure(figsize=(10, 6))
avg_price.plot(kind="bar", color="cornflowerblue", edgecolor="black", alpha=0.75)
plt.xlabel("Modèle d’iPhone", fontsize=12)
plt.ylabel("Prix moyen (€)", fontsize=12)
plt.title("Moyenne des prix par modèle d’iPhone 💰", fontsize=14, fontweight="bold")
plt.xticks(rotation=45, ha="right")
plt.grid(axis="y", linestyle="--", alpha=0.7)

# 📌 Ajouter une légende
plt.legend(["Prix moyen par modèle"], loc="upper left")

# 📌 Enregistrement de la figure
output_path = "projet_final/moyenne_prix_modeles.png"
os.makedirs("projet_final", exist_ok=True)
plt.savefig(output_path, dpi=300)

print(f"✅ Barplot enregistré sous {output_path}")

plt.show()
# 📊 Création du Scatter Plot
plt.figure(figsize=(8, 6))
plt.scatter(df["price"], df["reviews"], color="royalblue", alpha=0.7, edgecolors="black")
plt.xlabel("Prix (€)", fontsize=12)
plt.ylabel("Nombre d’avis", fontsize=12)
plt.title("Corrélation entre prix et nombre d’avis 🔗", fontsize=14, fontweight="bold")
plt.grid(True, linestyle="--", alpha=0.7)

# 📌 Ajouter une légende
plt.legend(["Chaque point représente un iPhone"], loc="upper left")

# 📌 Enregistrement de la figure
output_path = "projet_final/correlation_prix_avis.png"
plt.savefig(output_path, dpi=300)

print(f"✅ Scatter plot enregistré sous {output_path}")

plt.show()
# 📌 Ajouter une colonne de catégories de prix
def categorize_price(price):
    if price < 700:
        return "Entrée de gamme"
    elif 700 <= price < 1200:
        return "Moyenne gamme"
    else:
        return "Haut de gamme"

df["price_category"] = df["price"].apply(categorize_price)

# 📊 Création du Pie Chart
plt.figure(figsize=(8, 8))
df["price_category"].value_counts().plot(kind="pie", autopct="%1.1f%%", startangle=90, colors=["lightgreen", "gold", "tomato"], wedgeprops={"edgecolor": "black"})

plt.title("Répartition des iPhones selon les catégories 📊", fontsize=14, fontweight="bold")

# 📌 Ajouter une légende
plt.legend(["Entrée de gamme", "Moyenne gamme", "Haut de gamme"], loc="upper right")

# 📌 Enregistrement de la figure
output_path = "projet_final/repartition_categories.png"
plt.savefig(output_path, dpi=300)

print(f"✅ Pie chart enregistré sous {output_path}")

plt.show()
