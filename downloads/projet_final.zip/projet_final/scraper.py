import requests
from bs4 import BeautifulSoup
import csv

# URL de la catégorie iPhone sur Boulanger
URL = "https://www.boulanger.com/c/iphone"

# En-tête User-Agent pour éviter d'être bloqué
headers = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/114.0.0.0 Safari/537.36"
    )
}

# Récupération de la page web
response = requests.get(URL, headers=headers, timeout=10)

if response.status_code == 200:
    soup = BeautifulSoup(response.text, "html.parser")

    # Trouver les blocs produits
    products = soup.find_all("li", class_="product-list__item")

    print("📌 Nombre de produits trouvés :", len(products))  # Vérification

    # Création du fichier CSV
    with open("iphones.csv", "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["name", "price", "category", "link", "reviews"])

        for product in products:
            # 🔄 **Correction pour récupérer le nom et supprimer les espaces inutiles**
            name_tag = product.find("h2", class_="product-list__product-label")
            name = name_tag.text.replace("\n", " ").strip() if name_tag else "N/A"

            # 🔄 **Correction pour récupérer le prix avec la bonne classe**
            price_tag = product.find("p", class_="price__amount")  # 🔥 Correction ici
            price_str = price_tag.text.strip() if price_tag else "0"
            price_str = price_str.replace("€", "").replace(",", ".")  # Nettoyage format prix

            try:
                price_value = float(price_str)
            except ValueError:
                price_value = 0.0  # Si la conversion échoue

            # 📢 **Debugging : Vérifie si le prix est bien récupéré**
            if price_value == 0.0:
                print(f"⚠ Problème de prix pour : {name}")

            # Catégorie fixée à "iPhone"
            category = "iPhone"

            # Extraction du lien vers la fiche produit
            link_tag = product.find("a", href=True)
            link = link_tag["href"] if link_tag else "N/A"
            if link != "N/A" and not link.startswith("http"):
                link = "https://www.boulanger.com" + link

            # Extraction du nombre d'avis (si disponible)
            reviews_tag = product.find("span", class_="rating-count")
            reviews_str = reviews_tag.text.strip() if reviews_tag else "0"
            try:
                reviews_value = int(reviews_str)
            except ValueError:
                reviews_value = 0

            # Écriture des données dans le fichier CSV
            writer.writerow([name, price_value, category, link, reviews_value])

    print("✅ Scraping terminé, données enregistrées dans 'iphones.csv'.")
else:
    print("❌ Erreur lors de la récupération de la page :", response.status_code)
