import mysql.connector
import pandas as pd

# 📌 Connexion à la base de données MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="ecommerce"
)
cursor = conn.cursor()

# 📌 Charger les données nettoyées
df = pd.read_csv("iphones_cleaned.csv")

# 📌 Vérifier les colonnes disponibles
print("📌 Colonnes disponibles :", df.columns)

# 📌 Insertion des données dans MySQL (sans `review_text`)
for _, row in df.iterrows():
    sql = """
    INSERT INTO iphones (name, price, category, link, rating)
    VALUES (%s, %s, %s, %s, %s)
    """
    values = (row["name"], row["price"], row["category"], row["link"], row["reviews"])  # 🔄 Correction ici
    cursor.execute(sql, values)

# ✅ Valider et fermer la connexion
conn.commit()
cursor.close()
conn.close()

print("✅ Données insérées dans MySQL avec succès !")
