# 📌 Projet Final - Analyse des iPhones sur Boulanger

## 📖 Description du Projet
Ce projet a pour objectif d'extraire, nettoyer, analyser et visualiser les données des iPhones disponibles sur le site **Boulanger**. Nous avons utilisé **Python** et différentes bibliothèques pour effectuer le scraping, le stockage en **MySQL**, et l'analyse des données.

---

## 📁 Structure du Projet

```
projet_final/
│-- scraper.py  # Script de scraping
│-- cleaning.py  # Nettoyage des données
│-- store_mysql.py  # Stockage des données en MySQL
│-- visualization.py  # Visualisation des données
│-- iphones.csv  # Données brutes après scraping
│-- iphones_cleaned.csv  # Données nettoyées
│-- ecommerce.sql  # Exportation de la base de données MySQL
│-- projet_final/
│   ├── histogramme_prix.png  # Histogramme des prix
│   ├── correlation_prix_avis.png  # Scatter plot
│   ├── moyenne_prix_modeles.png  # Barplot
│   ├── repartition_gamme.png  # Graphique de répartition des gammes de prix
│   ├── repartition_categories.png  # Pie chart
│-- README.md  # Documentation du projet
```

---

## 🚀 Technologies Utilisées

📌 **Python** (3.x)  
📌 **Pandas** - Manipulation des données  
📌 **BeautifulSoup** - Web Scraping  
📌 **Requests** - Requêtes HTTP  
📌 **Matplotlib** - Visualisation  
📌 **MySQL (via XAMPP)** - Stockage des données  
📌 **Git Bash** - Exécution des commandes  

---

## 📌 Installation et Exécution

### 🔹 1. Installation des Bibliothèques
Assurez-vous d’avoir **Python 3.x** installé puis exécutez :
```sh
pip install -r requirements.txt  # Si un fichier requirements.txt existe
```
Sinon, installez-les manuellement :
```sh
pip install requests beautifulsoup4 pandas mysql-connector-python matplotlib
```

### 🔹 2. Exécuter le Scraping
Lancez le script pour récupérer les données :
```sh
python scraper.py
```
📌 Résultat : les données sont enregistrées dans **iphones.csv**

### 🔹 3. Nettoyage des Données
Nettoyer les données et enregistrer un nouveau fichier :
```sh
python cleaning.py
```
📌 Résultat : fichier **iphones_cleaned.csv**

### 🔹 4. Stockage des Données dans MySQL
Créer la base de données et insérer les données :
```sh
python store_mysql.py
```
📌 Résultat : les données sont stockées dans **MySQL**

### 🔹 5. Génération des Visualisations
Générer tous les graphiques :
```sh
python visualization.py
```
📌 Résultat : les images des graphiques sont enregistrées dans **projet_final/**

---

## 📊 Visualisations Générées
- **Histogramme des prix** - `histogramme_prix.png`
- **Corrélation prix vs avis** - `correlation_prix_avis.png`
- **Moyenne des prix par modèle** - `moyenne_prix_modeles.png`
- **Répartition par gamme** - `repartition_gamme.png`
- **Répartition par catégories** - `repartition_categories.png`

---

## 🛠 Améliorations Possibles
✅ Ajout de nouvelles métriques (ex. évolution des prix)  
✅ Scraping de plusieurs pages pour plus de données  
✅ Comparaison des prix avec d’autres sites e-commerce  

---

## 📌 Auteurs
👨‍💻 **[Votre Nom]**  
📅 **Sprint Data - Projet Final 2025**  
📩 Contact : [Votre Email]

