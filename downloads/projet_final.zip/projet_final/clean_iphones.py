import pandas as pd
from rich.console import Console
from rich.table import Table

# Charger les données du CSV
df = pd.read_csv("iphones.csv")

# Nettoyage des espaces inutiles dans les noms
df["name"] = df["name"].str.replace(r"\s+", " ", regex=True).str.strip()

# Tri des iPhones par prix (du moins cher au plus cher)
df = df.sort_values(by="price")

# Sauvegarde du CSV propre
df.to_csv("iphones_cleaned.csv", index=False)

# 📌 Affichage avec Rich (tableau en couleur et espacé)
console = Console()
table = Table(title="📱 iPhones Scraped Data", style="bold cyan")

# Ajouter les colonnes avec couleur et élargissement des colonnes
table.add_column("Name", style="bold magenta", min_width=40, justify="left")
table.add_column("Price (€)", justify="right", style="yellow", min_width=10)
table.add_column("Category", style="green", min_width=10)
table.add_column("Link", style="blue", min_width=30, overflow="fold")
table.add_column("Reviews", justify="center", style="red", min_width=8)

# Ajouter les lignes du tableau avec séparation
for i, row in df.head(15).iterrows():  # Afficher les 15 premiers
    table.add_row(row["name"], f"{row['price']:.2f}", row["category"], row["link"], str(row["reviews"]))
    table.add_section()  # Ajoute une ligne de séparation entre chaque produit

console.print(table)
